--Retrieve Companies Ranked by Revenue
SELECT	C.CompanyName,
	SUM(SOH.TotalDue) AS Revenue,
RANK() OVER (ORDER BY SUM(SOH.TotalDue) DESC) AS RankByRevenue
FROM SalesLT.SalesOrderHeader AS SOH
JOIN SalesLT.Customer AS C
ON SOH.CustomerID=C.CustomerID;